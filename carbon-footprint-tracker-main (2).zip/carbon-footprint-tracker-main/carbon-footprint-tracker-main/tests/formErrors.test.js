import { describe, test, expect } from 'vitest';
import { clearFormErrors, applyValidationErrors } from '../src/utils/formErrors.js';

describe('formErrors utils', () => {
  test('clearFormErrors hides messages and removes input error classes', () => {
    document.body.innerHTML = `
      <form>
        <div id="error-a" class="form-error" style="display:flex;">Quantity is required.</div>
        <div id="error-b" class="form-error" style="display:flex;">Date is required.</div>
        <input id="input-a" class="form-input form-input--error" />
        <input id="input-b" class="form-input form-input--error" />
      </form>
    `;

    const container = document.body;
    clearFormErrors(container);

    expect(document.querySelector('#error-a').textContent).toBe('');
    expect(document.querySelector('#error-a').style.display).toBe('none');
    expect(document.querySelector('#error-b').textContent).toBe('');
    expect(document.querySelector('#error-b').style.display).toBe('none');
    expect(document.querySelector('#input-a').classList.contains('form-input--error')).toBe(false);
    expect(document.querySelector('#input-b').classList.contains('form-input--error')).toBe(false);
  });

  test('applyValidationErrors maps messages to configured fields', () => {
    document.body.innerHTML = `
      <form>
        <div id="error-quantity" class="form-error" style="display:none;"></div>
        <div id="error-date" class="form-error" style="display:none;"></div>
        <input id="quantity-input" class="form-input" />
        <input id="date-input" class="form-input" />
      </form>
    `;

    const fieldMap = [
      {
        match: (error) => error.includes('Quantity'),
        errorSelector: '#error-quantity',
        inputSelector: '#quantity-input',
      },
      {
        match: (error) => error.includes('Date'),
        errorSelector: '#error-date',
        inputSelector: '#date-input',
      },
    ];

    applyValidationErrors(['Quantity is required.', 'Date must be valid.'], document.body, fieldMap);

    expect(document.querySelector('#error-quantity').textContent).toBe('Quantity is required.');
    expect(document.querySelector('#error-quantity').style.display).toBe('flex');
    expect(document.querySelector('#quantity-input').classList.contains('form-input--error')).toBe(true);

    expect(document.querySelector('#error-date').textContent).toBe('Date must be valid.');
    expect(document.querySelector('#error-date').style.display).toBe('flex');
    expect(document.querySelector('#date-input').classList.contains('form-input--error')).toBe(true);
  });

  test('applyValidationErrors ignores unmatched errors and invalid inputs', () => {
    document.body.innerHTML = `
      <form>
        <div id="error-quantity" class="form-error" style="display:none;"></div>
        <input id="quantity-input" class="form-input" />
      </form>
    `;

    const fieldMap = [
      {
        match: (error) => error.includes('Quantity'),
        errorSelector: '#error-quantity',
        inputSelector: '#quantity-input',
      },
    ];

    applyValidationErrors(['Unknown issue'], document.body, fieldMap);
    expect(document.querySelector('#error-quantity').textContent).toBe('');
    expect(document.querySelector('#quantity-input').classList.contains('form-input--error')).toBe(false);

    applyValidationErrors(['Quantity is required.'], null, fieldMap);
    applyValidationErrors(['Quantity is required.'], document.body, null);
  });
});
