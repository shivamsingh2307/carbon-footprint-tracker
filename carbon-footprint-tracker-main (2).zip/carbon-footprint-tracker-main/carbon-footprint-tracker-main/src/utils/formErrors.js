/**
 * Shared helpers for clearing and rendering form validation errors.
 * @module formErrors
 */

/**
 * Clear all visible validation errors and error input styles.
 * @param {HTMLElement} container
 */
export function clearFormErrors(container) {
  if (!container) return;

  container.querySelectorAll('.form-error').forEach((el) => {
    el.textContent = '';
    el.style.display = 'none';
  });

  container.querySelectorAll('.form-input').forEach((el) => {
    el.classList.remove('form-input--error');
  });
}

/**
 * Apply error messages to mapped fields.
 * @param {string[]} errors
 * @param {HTMLElement} container
 * @param {Array<{match: (error: string) => boolean, errorSelector: string, inputSelector: string}>} fieldMap
 */
export function applyValidationErrors(errors, container, fieldMap) {
  if (!container || !Array.isArray(errors) || !Array.isArray(fieldMap)) return;

  errors.forEach((error) => {
    const mappedField = fieldMap.find((field) => field.match(error));
    if (!mappedField) return;

    const errorEl = container.querySelector(mappedField.errorSelector);
    const inputEl = container.querySelector(mappedField.inputSelector);

    if (errorEl) {
      errorEl.textContent = error;
      errorEl.style.display = 'flex';
    }

    if (inputEl) {
      inputEl.classList.add('form-input--error');
    }
  });
}
