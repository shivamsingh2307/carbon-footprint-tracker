/**
 * ActivityLogger Component — Form for logging new carbon-emitting or green activities.
 * @module ActivityLogger
 */

import { CATEGORIES, CATEGORY_META, getFactorsByCategory, getFactorById } from '../data/emissionFactors.js';
import { calculateEmission } from '../services/CalculatorService.js';
import { addActivity, deleteActivity } from '../services/StorageService.js';
import { checkAchievements } from '../services/AchievementService.js';
import { validateActivity } from '../utils/validators.js';
import { sanitizeString, sanitizeNumber, sanitizeDate } from '../utils/sanitize.js';
import { clearFormErrors, applyValidationErrors } from '../utils/formErrors.js';
import { getTodayISO } from '../utils/formatters.js';
import { showToast } from './Toast.js';

const MAX_ACTIVITY_QUANTITY = 10000;
const MAX_NOTES_LENGTH = 500;

let activeCategory = CATEGORIES.TRANSPORT;

/**
 * Render the activity logger view.
 * @param {HTMLElement} container - The mount element
 */
export function initActivityLogger(container) {
  if (!container) return;
  renderLogger(container);
}

function renderLogger(container) {
  container.innerHTML = `
    <div class="logger-container card fade-in" style="max-width: 680px; margin: 0 auto;">
      <div class="card-header">
        <h2 class="card-title">Log New Activity</h2>
        <p class="card-subtitle">Choose a category and enter details to calculate emissions</p>
      </div>

      <form id="activity-form" novalidate>
        <div class="form-group">
          <span class="form-label">Select Category</span>
          <div class="category-grid" role="radiogroup" aria-label="Activity category">
            ${CATEGORY_META.map(
              (cat) => `
              <div class="category-card ${cat.id === activeCategory ? 'active' : ''}"
                   data-category="${cat.id}"
                   role="radio"
                   aria-checked="${cat.id === activeCategory}"
                   tabindex="0"
                   aria-label="${cat.name}">
                <div class="category-icon" aria-hidden="true">${cat.icon}</div>
                <div class="category-name">${cat.name}</div>
              </div>
            `
            ).join('')}
          </div>
        </div>

        <div class="grid grid-2">
          <div class="form-group">
            <label class="form-label" for="activity-select">Activity Type</label>
            <select class="form-select" id="activity-select" required></select>
            <div class="form-error" id="error-activity-select" style="display: none;"></div>
          </div>

          <div class="form-group">
            <label class="form-label" for="quantity-input">Quantity (<span id="unit-label">units</span>)</label>
            <input class="form-input" type="number" id="quantity-input" placeholder="0" min="0" step="any" required />
            <div class="form-error" id="error-quantity-input" style="display: none;"></div>
          </div>
        </div>

        <div class="grid grid-2">
          <div class="form-group">
            <label class="form-label" for="date-input">Date</label>
            <input class="form-input" type="date" id="date-input" max="${getTodayISO()}" value="${getTodayISO()}" required />
            <div class="form-error" id="error-date-input" style="display: none;"></div>
          </div>

          <div class="form-group" style="display: flex; flex-direction: column; justify-content: flex-end;">
            <div class="card stat-card" style="padding: var(--space-3); background: var(--bg-input); border-color: var(--border-secondary); margin-bottom: 0;">
              <div class="stat-value" id="preview-value" style="font-size: var(--font-size-xl);">0.0 kg</div>
              <div class="stat-label">Estimated CO₂e</div>
            </div>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="notes-input">Notes (Optional)</label>
          <textarea class="form-input" id="notes-input" placeholder="e.g. Commute to work, Vegan burger, etc." maxlength="${MAX_NOTES_LENGTH}"></textarea>
          <div class="form-error" id="error-notes-input" style="display: none;"></div>
        </div>

        <div style="display: flex; justify-content: flex-end; margin-top: var(--space-4);">
          <button type="submit" class="btn btn-primary btn-lg" id="submit-btn">Log Activity</button>
        </div>
      </form>
    </div>
  `;

  const form = container.querySelector('#activity-form');
  const activitySelect = container.querySelector('#activity-select');
  const quantityInput = container.querySelector('#quantity-input');
  const unitLabel = container.querySelector('#unit-label');
  const dateInput = container.querySelector('#date-input');
  const notesInput = container.querySelector('#notes-input');
  const previewValue = container.querySelector('#preview-value');

  const validationFieldMap = getValidationFieldMap();

  populateActivities(activeCategory, activitySelect);
  updateUnitLabel(activitySelect, unitLabel);

  wireCategorySelection(container, activitySelect, quantityInput, unitLabel, previewValue);

  activitySelect.addEventListener('change', () => {
    updateUnitLabel(activitySelect, unitLabel);
    updatePreview(activitySelect, quantityInput, previewValue);
  });

  quantityInput.addEventListener('input', () => {
    updatePreview(activitySelect, quantityInput, previewValue);
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    clearFormErrors(container);

    const rawData = {
      activityId: activitySelect.value,
      quantity: quantityInput.value === '' ? null : Number(quantityInput.value),
      date: dateInput.value,
      notes: notesInput.value,
    };

    const validation = validateActivity(rawData);
    if (!validation.valid) {
      applyValidationErrors(validation.errors, container, validationFieldMap);
      return;
    }

    const cleanQuantity = sanitizeNumber(rawData.quantity, 0, MAX_ACTIVITY_QUANTITY);
    const cleanDate = sanitizeDate(rawData.date);
    const cleanNotes = sanitizeString(rawData.notes, MAX_NOTES_LENGTH);
    const factor = getFactorById(rawData.activityId);
    const emission = calculateEmission(rawData.activityId, cleanQuantity);

    const savedEntry = addActivity({
      activityId: rawData.activityId,
      category: activeCategory,
      quantity: cleanQuantity,
      unit: factor ? factor.unit : '',
      date: cleanDate,
      notes: cleanNotes,
      emission,
    });

    showToast({
      message: `Logged ${factor ? factor.name : 'activity'} (${emission} kg CO₂e)`,
      type: 'success',
      action: {
        label: 'Undo',
        onClick: () => {
          deleteActivity(savedEntry.id);
          showToast({ message: 'Activity entry deleted', type: 'info' });
        },
      },
    });

    form.reset();
    dateInput.value = getTodayISO();
    updatePreview(activitySelect, quantityInput, previewValue);

    // Achievement checks run after storage is updated so streak/volume badges stay accurate.
    checkAchievements();
  });
}

function getValidationFieldMap() {
  return [
    {
      match: (error) => error.includes('Activity'),
      errorSelector: '#error-activity-select',
      inputSelector: '#activity-select',
    },
    {
      match: (error) => error.includes('Quantity'),
      errorSelector: '#error-quantity-input',
      inputSelector: '#quantity-input',
    },
    {
      match: (error) => error.includes('Date'),
      errorSelector: '#error-date-input',
      inputSelector: '#date-input',
    },
    {
      match: (error) => error.includes('Notes'),
      errorSelector: '#error-notes-input',
      inputSelector: '#notes-input',
    },
  ];
}

function wireCategorySelection(container, activitySelect, quantityInput, unitLabel, previewValue) {
  container.querySelectorAll('.category-card').forEach((card) => {
    card.addEventListener('click', () => {
      const selectedCategory = card.dataset.category;
      if (selectedCategory === activeCategory) {
        return;
      }

      activeCategory = selectedCategory;
      container.querySelectorAll('.category-card').forEach((item) => {
        item.classList.remove('active');
        item.setAttribute('aria-checked', 'false');
      });

      card.classList.add('active');
      card.setAttribute('aria-checked', 'true');

      populateActivities(activeCategory, activitySelect);
      updateUnitLabel(activitySelect, unitLabel);
      updatePreview(activitySelect, quantityInput, previewValue);
    });

    card.addEventListener('keydown', (event) => {
      if (event.key === ' ' || event.key === 'Enter') {
        event.preventDefault();
        card.click();
      }
    });
  });
}

function populateActivities(category, selectEl) {
  const factors = getFactorsByCategory(category);
  selectEl.innerHTML = factors
    .map((factor) => `<option value="${factor.id}">${factor.name} — ${factor.description}</option>`)
    .join('');
}

function updateUnitLabel(selectEl, labelEl) {
  const factor = getFactorById(selectEl.value);
  if (factor && labelEl) {
    labelEl.textContent = factor.unit;
  }
}

function updatePreview(selectEl, inputEl, previewEl) {
  const activityId = selectEl.value;
  const quantity = Number(inputEl.value);

  if (!activityId || Number.isNaN(quantity) || quantity <= 0) {
    previewEl.textContent = '0.0 kg';
    return;
  }

  const emission = calculateEmission(activityId, quantity);
  previewEl.textContent = `${emission.toFixed(1)} kg`;
}
