/**
 * Dashboard Component — Main overview screen with statistics, charts, and activity feed.
 * @module Dashboard
 */

import {
  getPeriodTotal,
  getDailyTotal,
  getCategoryBreakdown,
  getTrendData,
  getEquivalencies,
  getCurrentStreak,
  getBestDay,
} from '../services/CalculatorService.js';
import { getActivities, deleteActivity } from '../services/StorageService.js';
import { createDoughnutChart, createLineChart } from './ChartManager.js';
import { formatCO2, getTodayISO, formatDate } from '../utils/formatters.js';
import { showToast } from './Toast.js';
import { openModal } from './Modal.js';

let activePeriodDays = 7;

const RECENT_ACTIVITY_LIMIT = 5;
const CATEGORY_ICONS = {
  transport: '🚗',
  food: '🍽️',
  energy: '⚡',
  home: '🏠',
  shopping: '🛍️',
  waste: '♻️',
};
const CATEGORY_NAMES = {
  transport: 'Transport',
  food: 'Food',
  energy: 'Energy',
  home: 'Home',
  shopping: 'Shopping',
  waste: 'Waste',
};

/**
 * Render the dashboard view.
 * @param {HTMLElement} container - The mount element
 */
export function initDashboard(container) {
  if (!container) return;
  renderDashboard(container);
}

function renderDashboard(container) {
  const data = getDashboardData();

  container.innerHTML = renderDashboardTemplate(data);

  renderDashboardCharts(data);
  bindPeriodSelection(container);
  bindDeleteActivityButtons(container);
}

function getDashboardData() {
  const today = getTodayISO();
  const periodTotal = getPeriodTotal(activePeriodDays);

  // Snapshot all values once per render to avoid repeated storage/service calls.
  return {
    todayEmissions: getDailyTotal(today),
    streak: getCurrentStreak(),
    periodTotal,
    bestDayData: getBestDay(activePeriodDays),
    equivalencies: getEquivalencies(periodTotal),
    breakdown: getCategoryBreakdown(activePeriodDays),
    recentActivities: getActivities().slice(0, RECENT_ACTIVITY_LIMIT),
    trendData: getTrendData(activePeriodDays),
  };
}

function renderDashboardTemplate(data) {
  return `
    <div class="dashboard-grid grid">
      ${renderHeroSection(data)}
      ${renderStatsSection(data)}
      <div class="grid grid-2 fade-in" style="animation-delay: 200ms;">
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Emission Trend</h3>
              <p class="card-subtitle">Daily emissions time series</p>
            </div>
            <div class="period-selector" role="radiogroup" aria-label="Select trend period">
              <button class="period-btn ${activePeriodDays === 7 ? 'active' : ''}" data-days="7" role="radio" aria-checked="${activePeriodDays === 7}">7D</button>
              <button class="period-btn ${activePeriodDays === 30 ? 'active' : ''}" data-days="30" role="radio" aria-checked="${activePeriodDays === 30}">30D</button>
              <button class="period-btn ${activePeriodDays === 90 ? 'active' : ''}" data-days="90" role="radio" aria-checked="${activePeriodDays === 90}">90D</button>
            </div>
          </div>
          <div class="chart-container" style="height: 250px;">
            <canvas id="trend-line-canvas"></canvas>
          </div>
        </div>

        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Recent Activities</h3>
              <p class="card-subtitle">Your latest logged entries</p>
            </div>
          </div>
          <div class="activity-feed">${renderRecentActivities(data.recentActivities)}</div>
        </div>
      </div>
    </div>
  `;
}

function renderHeroSection(data) {
  return `
    <div class="card card-hero fade-in">
      <div class="card-header">
        <h2 class="card-title">Carbon Footprint Summary</h2>
        <span class="badge badge-primary">${activePeriodDays} Days View</span>
      </div>
      <div class="hero-content grid grid-2">
        <div class="hero-left">
          <p class="hero-label">Total CO₂e Emitted</p>
          <h1 class="hero-value count-up">${formatCO2(data.periodTotal, 1)}</h1>
          <p class="hero-subtext">Equivalent to planting <strong>${data.equivalencies.trees.toFixed(1)}</strong> trees this year.</p>
        </div>
        <div class="hero-right chart-wrapper" style="height: 180px; position: relative;">
          <canvas id="category-doughnut-canvas"></canvas>
        </div>
      </div>
    </div>
  `;
}

function renderStatsSection(data) {
  return `
    <div class="stats-container grid grid-4 fade-in" style="animation-delay: 100ms;">
      <div class="card stat-card">
        <span class="stat-icon" aria-hidden="true" style="font-size: var(--font-size-2xl);">💨</span>
        <div class="stat-value">${formatCO2(data.todayEmissions, 1)}</div>
        <div class="stat-label">Today's Emissions</div>
      </div>

      <div class="card stat-card">
        <span class="stat-icon" aria-hidden="true" style="font-size: var(--font-size-2xl);">🔥</span>
        <div class="stat-value">${data.streak}</div>
        <div class="stat-label">Logging Streak (Days)</div>
      </div>

      <div class="card stat-card">
        <span class="stat-icon" aria-hidden="true" style="font-size: var(--font-size-2xl);">🌿</span>
        <div class="stat-value">${data.bestDayData ? formatCO2(data.bestDayData.total, 1) : '0 kg'}</div>
        <div class="stat-label">Best Day (${data.bestDayData ? formatDate(data.bestDayData.date) : 'No data'})</div>
      </div>

      <div class="card stat-card">
        <span class="stat-icon" aria-hidden="true" style="font-size: var(--font-size-2xl);">🌳</span>
        <div class="stat-value">${data.equivalencies.trees.toFixed(1)}</div>
        <div class="stat-label">Trees Required to Offset</div>
      </div>
    </div>
  `;
}

function renderRecentActivities(recentActivities) {
  if (recentActivities.length === 0) {
    return `
      <div class="empty-state">
        <div class="empty-state-icon">📝</div>
        <div class="empty-state-title">No activities logged yet</div>
        <p class="empty-state-text">Go to the "Log Activity" tab to start building your carbon profile.</p>
      </div>
    `;
  }

  return recentActivities.map((activity) => renderActivityRow(activity)).join('');
}

function renderActivityRow(activity) {
  return `
    <div class="activity-item" data-id="${activity.id}">
      <div class="activity-icon-wrap" aria-hidden="true">
        ${getCategoryIcon(activity.category)}
      </div>
      <div class="activity-details">
        <div class="activity-name">${activity.notes || getCategoryName(activity.category)}</div>
        <div class="activity-meta">${activity.quantity} ${activity.unit || ''} • ${formatDate(activity.date, 'relative')}</div>
      </div>
      <div class="activity-emission">${formatCO2(activity.emission, 1)}</div>
      <button class="btn btn-icon btn-ghost delete-activity-btn" aria-label="Delete activity entry" data-id="${activity.id}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="3 6 5 6 21 6"></polyline>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
        </svg>
      </button>
    </div>
  `;
}

function renderDashboardCharts(data) {
  // Skip doughnut chart when there is no meaningful data to avoid empty visual noise.
  if (data.breakdown.length > 0 && data.periodTotal > 0) {
    const chartLabels = data.breakdown.map((item) => item.name);
    const chartValues = data.breakdown.map((item) => item.total);
    const chartColors = data.breakdown.map((item) => item.color);
    createDoughnutChart('category-doughnut-canvas', {
      labels: chartLabels,
      values: chartValues,
      colors: chartColors,
    });
  }

  createLineChart('trend-line-canvas', {
    labels: data.trendData.map((day) => formatDate(day.date)),
    values: data.trendData.map((day) => day.total),
  });
}

function bindPeriodSelection(container) {
  container.querySelectorAll('.period-btn').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      const button = event.currentTarget;
      const days = Number.parseInt(button.dataset.days, 10);
      if (days !== activePeriodDays) {
        activePeriodDays = days;
        renderDashboard(container);
      }
    });
  });
}

function bindDeleteActivityButtons(container) {
  container.querySelectorAll('.delete-activity-btn').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      const button = event.currentTarget;
      const activityId = button.dataset.id;
      if (!activityId) return;

      openModal({
        title: 'Delete Activity?',
        body: '<p>Are you sure you want to delete this activity? This action cannot be undone.</p>',
        actions: [
          {
            label: 'Cancel',
            className: 'btn-ghost',
          },
          {
            label: 'Delete',
            className: 'btn-danger',
            onClick: () => {
              const deleted = deleteActivity(activityId);
              if (deleted) {
                showToast({ message: 'Activity deleted successfully', type: 'success' });
                renderDashboard(container);
              } else {
                showToast({ message: 'Failed to delete activity', type: 'error' });
              }
            },
          },
        ],
      });
    });
  });
}

function getCategoryIcon(category) {
  return CATEGORY_ICONS[category] || '🌱';
}

function getCategoryName(category) {
  return CATEGORY_NAMES[category] || 'Activity';
}
